<?php
namespace League\Consumers;

interface IObserver 
{
    public function update();
    
}//IObserver
